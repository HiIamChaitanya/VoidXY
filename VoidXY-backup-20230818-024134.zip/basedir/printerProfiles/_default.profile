axes:
  e:
    inverted: false
    speed: 300
  x:
    inverted: false
    speed: 6000
  y:
    inverted: false
    speed: 6000
  z:
    inverted: false
    speed: 200
color: default
extruder:
  count: 1
  defaultExtrusionLength: 5
  nozzleDiameter: 1.0
  offsets:
  - - 0.0
    - 0.0
  sharedNozzle: false
heatedBed: true
heatedChamber: false
id: _default
model: VoidXY v1
name: VoidXY
volume:
  custom_box: false
  depth: 190.0
  formFactor: rectangular
  height: 120.0
  origin: lowerleft
  width: 190.0
